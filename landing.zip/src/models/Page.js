const fs = require("fs");
const path = require("path");
const data = fs.readFileSync(path.join(__dirname, "data.json"));
const Page = {
  data: JSON.parse(data.toString()),
  getData: function () {
    return this.data;
  },
  editInfoData: function (__data) {
    this.data = {
      ...this.data,
      ...__data,
    };

    this.save();
  },
  deleteService: function (index) {
    let remove = this.data.services.splice(index, 1);
    fs.unlinkSync(
      path.resolve(
        __dirname,
        "../public/assets/image/service",
        remove[0].fileName
      )
    );
    this.save();
  },
  addService: function (service) {
    this.data.services.push(service);
    this.save();
  },
  deleteProject: function (index) {
    let remove = this.data.projects.splice(index, 1);
    fs.unlinkSync(
      path.resolve(
        __dirname,
        "../public/assets/image/project",
        remove[0].fileName
      )
    );
    this.save();
  },
  addProject: function (project) {
    this.data.projects.push(project);
    this.save();
  },
  save: function () {
    fs.writeFileSync(
      path.join(__dirname, "data.json"),
      JSON.stringify(this.data)
    );
  },
};

module.exports = Page;
